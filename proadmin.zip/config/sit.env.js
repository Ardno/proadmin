module.exports = {
    NODE_ENV: '"production"',
    ENV_CONFIG: '"sit"',
    BASE_API: '"http://gridmap.xiaoketech.com/"',
    APP_ORIGIN: '"http://gridmap.xiaoketech.com/"'
};
