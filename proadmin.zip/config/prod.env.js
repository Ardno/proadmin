module.exports = {
    NODE_ENV: '"production"',
    ENV_CONFIG: '"prod"',
    BASE_API: '"http://gridmap.xiaoketech.com/"',
    upload_API: '"http://gridmap-file.xiaoketech.com/"',
    APP_ORIGIN: '"http://gridmap.xiaoketech.com/"'
};
